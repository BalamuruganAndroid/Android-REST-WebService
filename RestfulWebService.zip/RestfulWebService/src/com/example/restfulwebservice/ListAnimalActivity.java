package com.example.restfulwebservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.support.v7.app.ActionBarActivity;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ListActivity;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;


@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class ListAnimalActivity extends ListActivity 
{

	//JSONParser jsonParser;
	Button btnGetList;
	static InputStream is = null;
	static JSONObject jObj = null;
	static String value = "";
	JSONParser jParser;
	ArrayList animalList;
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list_animal);
		btnGetList = (Button)findViewById(R.id.idSelect);
		jParser = new JSONParser();
		
		if (android.os.Build.VERSION.SDK_INT > 9)
		{
		    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		    StrictMode.setThreadPolicy(policy);
		}
		btnGetList.setOnClickListener(new OnClickListener() 
		{
			
			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub
				
				 try 
				 {
					 
					 List<NameValuePair> params = new ArrayList<NameValuePair>();
					 animalList = new ArrayList();
					 //ArrayList<HashMap<String, String>> productsList = new ArrayList<HashMap<String,String>>();
					// JSONObject jsonObj = jParser.getJSONFromUrl("http://192.168.5.55/Animals/listanimal.php", params);
					 
				DefaultHttpClient httpClient = new DefaultHttpClient();
					 HttpPost httpPost = new HttpPost("http://192.168.5.55/Animals/listanimal.php");
					httpPost.setEntity(new UrlEncodedFormEntity(params));
					  HttpResponse httpResponse = httpClient.execute(httpPost);
					  HttpEntity httpEntity = httpResponse.getEntity();
					  is = httpEntity.getContent();
				} catch (IllegalStateException e)
				 {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
				 try {
			        	BufferedReader reader = new BufferedReader(new InputStreamReader(
			                    is, "utf-8"), 8);
			            StringBuilder sb = new StringBuilder();
			            String line = null;
			            while ((line = reader.readLine()) != null) 
			            {
			                sb.append(line);
			            }
			            is.close();
			            value = sb.toString();
			            Log.e("JSON", value);
			        } catch (Exception e) {
			            Log.e("Buffer Error", "Error converting result " + e.toString());
			        }

			        // try parse the string to a JSON object
			        try 
			        {
			  
			        	//String result= value.substring(6);
			        	 JSONArray jObj1 = new JSONArray(value);
			        	 
			        	 for (int i = 0; i < jObj1.length(); i++) 
			        	 {
		                        JSONObject c = jObj1.getJSONObject(i);
		                        String no = c.getString("NO");
		                        String name = c.getString("NAME");
		                        String type = c.getString("Type");
		                       System.out.println("Type" +type);
		                       // creating new HashMap
		                        HashMap map = new HashMap();
		 
		                        // adding each child node to HashMap key => value
		                        map.put("NO", no);
		                        map.put("NAME", name);
		                        map.put("Type", type);
		 
		                        // adding HashList to ArrayList
		                        animalList.add(map);
		                        
			        	 }
			        	 ListAdapter adapter = new SimpleAdapter(
	                        		ListAnimalActivity.this, animalList,
	                        		R.layout.add_animal, new String[] { "NO",
	                        		"NAME","Type"},
	                        		new int[] { R.id.animal_id, R.id.animal_name,R.id.animal_type });
	                        		setListAdapter(adapter);
	                        		
			        	 System.out.println("json array" + jObj1);
			            
			        } catch (JSONException e) {
			            Log.e("JSON Parser", "Error parsing data " + e.toString());
			        }
			}
		});
		 
	  	
	}
	/*public String getDataFromDB()
	{
        try
        {
 
            HttpPost httppost;
            HttpClient httpclient;
            httpclient = new DefaultHttpClient();
            httppost = new HttpPost("http://192.168.5.55/Animals/listanimal.php"); // change this to your URL.....
         //   ResponseHandler<String> responseHandler = new BasicResponseHandler();
            final String response = httpclient.execute(httppost,
                    responseHandler);
             
            return response.trim();
 
        } catch (Exception e)
        {
            System.out.println("ERROR : " + e.getMessage());
            return "error";
        }
    }*/

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.list_animal, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
