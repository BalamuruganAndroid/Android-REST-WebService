package com.example.restfulwebservice;

import java.io.InputStream;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class AddAnimalActivity extends Activity 
{
	EditText edtAnimalName,edtAnimalType;
	Button btnSave;
	InputStream is=null;
	String result=null;
	String line=null;
	int code;
	JSONParser jsonParser;
	private static String url = "http://192.168.5.55/zoo/list_animals.php";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_animal);
		edtAnimalName = (EditText)findViewById(R.id.animalName);
		edtAnimalType = (EditText)findViewById(R.id.animalType);
		btnSave = (Button)findViewById(R.id.idSave);
		 jsonParser = new JSONParser();
		btnSave.setOnClickListener(new OnClickListener() 
		{
			
			@TargetApi(Build.VERSION_CODES.GINGERBREAD)
			@SuppressLint("NewApi")
			@Override
			public void onClick(View v) 
			{
				if (android.os.Build.VERSION.SDK_INT > 9)
				{
				    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
				    StrictMode.setThreadPolicy(policy);
				}
				String animalName = edtAnimalName.getText().toString();
				String animalType = edtAnimalType.getText().toString();
				
				ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
				 
			   	nameValuePairs.add(new BasicNameValuePair("animalName",animalName));
			   	nameValuePairs.add(new BasicNameValuePair("animalType",animalType));
			   
			   	JSONObject josonObj =jsonParser.getJSONFromUrl("http://192.168.5.55/Animals/addAnimals.php", nameValuePairs);
			    
			   	try 
			    {
					 code=(josonObj.getInt("code"));
					 Toast.makeText(getApplicationContext(), "Inserted Succesfully", Toast.LENGTH_LONG).show();
				}
			    catch (JSONException e) 
			    {
					// TODO Auto-generated catch block
					e.printStackTrace();
				};
			   	
			   	
			   	
			   	/*try
		    	{
			   		HttpClient httpclient = new DefaultHttpClient();
			        HttpPost httppost = new HttpPost("http://192.168.5.55/Animals/addAnimals.php");
			        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			        HttpResponse response = httpclient.execute(httppost); 
			        HttpEntity entity = response.getEntity();
			        is = entity.getContent();
			        Log.e("pass 1", "connection success ");
		    	}
			        catch(Exception e)
				{
			        	Log.e("Fail 1", e.toString());
				    	Toast.makeText(getApplicationContext(), "Invalid IP Address",
						Toast.LENGTH_LONG).show();
				}  
			   	try
		        {
		           // BufferedReader reader = new BufferedReader
					//(new InputStreamReader(is,"iso-8859-1"),8);
			   		BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
			    {
		                sb.append(line + "\n");
		            }
		            is.close();
		            result = sb.toString();
			    Log.e("pass 2", "connection success ");
			}
		        catch(Exception e)
			{
		            Log.e("Fail 2", e.toString());
			}     
		       
			try
			{
		            JSONObject json_data = new JSONObject(result);
		            code=(json_data.getInt("code"));
					
		            if(code==1)
		            {
		            	Toast.makeText(getBaseContext(), "Inserted Successfully",
		            			Toast.LENGTH_SHORT).show();
		            }
		            else
		            {
		            	Toast.makeText(getBaseContext(), "Sorry, Try Again",
					Toast.LENGTH_LONG).show();
		            }
			}
			catch(Exception e)
			{
		            Log.e("Fail 3", e.toString());
			}*/
		        
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_animal, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
